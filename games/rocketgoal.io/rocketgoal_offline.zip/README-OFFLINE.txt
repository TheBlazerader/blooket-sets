ROCKETGOAL OFFLINE EDITION

Files included:
- Unity loader, framework, WebAssembly engine, and main data archive
- Local launcher (index.html)
- Original TemplateData support assets

IMPORTANT:
Unity WebGL generally needs to be served over HTTP rather than opened directly with file://.
For offline play, run a local static web server from this folder, then open:
http://localhost:8000/

If Python is installed:
  Windows: open Command Prompt in this folder and run:
    py -m http.server 8000
  macOS/Linux:
    python3 -m http.server 8000

Then open http://localhost:8000/ in a browser.
The server runs only on your own device; internet access is not needed to serve the local game files.

LIMITATIONS:
This is an offline single-player attempt. Firebase login/cloud data, online multiplayer,
remote configuration, ads, and payment services are not loaded. Features that depend on
those services will not work. The repository ZIP did not contain a StreamingAssets folder;
an empty local folder is included in case the build expects that path.
